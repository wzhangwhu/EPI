function compute_GO_semantic_value
%%
%% GO term Biologcial Process  BP term
%%
collect=importdata('PPI_sgdgenes_P_GOinteraction_missed_collect.mat');
[~, astrings] = xlsread('5093_PPI_DIP_data.xls');
n=length(astrings);
aaa=1:1:n;
bb=setdiff(aaa,collect);
[anumbers, ~] = xlsread('PPI_go_interaction_sim_result_P.xlsx');
result_P=zeros(1,n);
result_P(bb)=anumbers(:,2);
result_P(collect)=0;
result_P=result_P';
aa=isnan(result_P);
bb=find(aa==1);
result_P(bb)=0;
disp('GO ���ݲ���')
save PPI_go_interaction_sim_result_P_total.mat result_P